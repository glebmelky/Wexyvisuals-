# wexyvisuals

Fabric 1.21.4 client mod — rounded, custom-font ClickGUI, matching the approved HTML preview.

## Открыть GUI
Правый Shift (Right Shift) в игре открывает/закрывает ClickGUI. Меняется в Options > Controls
(биндинг называется "Open wexyvisuals ClickGUI").

## Структура

```
src/main/java/com/wexy/visuals/
  WexyVisualsClient.java      — точка входа мода (client entrypoint)
  KeyBindings.java             — регистрация клавиши Right Shift

  gui/
    ClickGuiScreen.java        — сам экран: сайдбар, грид карточек, панель настроек, тема-бар
    RoundedRenderUtil.java     — рендер скруглённых фигур без пикселей (вместо ванильного fill())
    widget/
      ToggleSwitch.java        — анимированный переключатель
      SliderWidget.java        — слайдер с плавным drag

  font/
    CustomFont.java            — кастомный TTF-рендер (STB), полностью в обход ванильного шрифта

  theme/
    Theme.java                 — 7 цветовых тем как в макете (white/blue/orange/green/cyan/pink/teal)
    ThemeManager.java          — текущая активная тема + базовая палитра фона/панелей

  module/
    Module.java                — модуль-заглушка: id, имя, описание, вкл/выкл, список Setting
    Setting.java                — один слайдер-параметр (min/max/value)
    Category.java               — Render / Visual / Utilities / Misc
    ModuleRegistry.java         — ЗДЕСЬ регистрируются все модули (см. ниже "Как добавить свои модули")

src/main/resources/assets/wexyvisuals/fonts/
  README.txt                  — куда положить wexy_regular.ttf и wexy_bold.ttf
```

## Как добавить свои модули (TargetESP, JumpCircle и т.д.)

В `ModuleRegistry.java` уже стоят заглушки с этими именами. Два варианта:

**Вариант А — просто вписать логику внутрь существующего Module:**
Отнаследоваться от `Module`, переопределить `onEnable()`/`onDisable()`, зарегистрировать инстанс
своего класса в `ModuleRegistry.init()` вместо строчки с `new Module(...)`.

**Вариант Б — прислать свои готовые .java классы:**
Если у модуля уже есть своя реализация (рендер-хуки, EventBus и т.д.), пришли файл — я:
1. поменяю package на `com.wexy.visuals.module.impl` (или как удобно),
2. заведу его как реальный `Module` в реестре вместо заглушки,
3. прокину `Setting`-параметры в правую панель GUI автоматически (ничего больше менять не надо —
   карточки и слайдеры генерируются из реестра сами).

## Шрифт

Заглушка на месте — код уже умеет грузить `wexy_regular.ttf` / `wexy_bold.ttf` из
`assets/wexyvisuals/fonts/`. Если файлов там нет, GUI не крашится — тихо откатывается на
ванильный Minecraft-шрифт. Инструкция по выбору бесплатного шрифта — в README.txt в той же папке.
