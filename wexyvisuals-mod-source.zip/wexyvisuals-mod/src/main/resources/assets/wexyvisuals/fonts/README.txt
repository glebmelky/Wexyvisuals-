Place two TTF font files here:
  wexy_regular.ttf
  wexy_bold.ttf

Recommended fonts to match the mockup's clean sans-serif look (all free/OFL, safe to bundle):
  - Poppins (Regular + SemiBold/Bold)      https://fonts.google.com/specimen/Poppins
  - Inter (Regular + Bold)                 https://fonts.google.com/specimen/Inter
  - Manrope (Regular + Bold)               https://fonts.google.com/specimen/Manrope

Download from Google Fonts, rename the two files to exactly:
  wexy_regular.ttf
  wexy_bold.ttf
and drop them in this folder before building the jar.

If these files are missing, CustomFont.java automatically falls back to the vanilla
Minecraft font at runtime (no crash) — so the mod still builds and runs without them,
it just won't have the custom look until you add the TTFs.
