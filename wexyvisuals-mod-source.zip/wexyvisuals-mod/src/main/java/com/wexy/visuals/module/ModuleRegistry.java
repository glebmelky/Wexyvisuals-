package com.wexy.visuals.module;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Central place all modules are registered. Mirrors the same module list used in the HTML
 * preview so the Jar GUI looks/behaves identically.
 *
 * HOW TO ADD YOUR OWN MODULES (e.g. TargetESP, JumpCircle):
 *   1. Either register a plain Module(...) here for a quick placeholder,
 *   2. Or create a dedicated class (e.g. TargetEspModule extends Module) that overrides
 *      onEnable()/onDisable() to hook your real rendering code, then register an instance
 *      of it here instead of a plain Module.
 * Nothing else in the GUI needs to change — cards, toggles and the settings panel are all
 * generated automatically from this registry.
 */
public final class ModuleRegistry {

    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleRegistry() {}

    public static void init() {
        if (!MODULES.isEmpty()) return; // idempotent

        // ---- Render ----
        register(new Module("clickgui", "ClickGUI", "Управление/Кастомизация", Category.RENDER, false));
        register(new Module("interface", "Interface", "Интерфейс клиента", Category.RENDER, true));
        register(new Module("targethud", "TargetHUD", "Показывает информацию о цели", Category.RENDER, true));
        register(new Module("dynamicisland", "DynamicIsland", "Центральный островок HUD", Category.RENDER, true));
        register(new Module("swinganimations", "SwingAnimations", "Красивые анимации для предмета в руке", Category.RENDER, true));

        Module viewModel = new Module("viewmodel", "ViewModel", "Изменение позиции рук", Category.RENDER, false);
        viewModel.addSetting(new Setting("RightX", -2f, 2f, -0.2f));
        viewModel.addSetting(new Setting("RightY", -2f, 2f, 0.1f));
        viewModel.addSetting(new Setting("RightZ", -2f, 2f, 0.2f));
        viewModel.addSetting(new Setting("LeftX", -2f, 2f, 0.0f));
        viewModel.addSetting(new Setting("LeftY", -2f, 2f, 0.0f));
        register(viewModel);

        Module aspectRatio = new Module("aspectratio", "AspectRatio", "Позволяет изменять соотношение сторон", Category.RENDER, false);
        aspectRatio.addSetting(new Setting("Ratio", 1.0f, 2.5f, 1.78f));
        register(aspectRatio);

        register(new Module("norender", "NoRender", "Убирает разные типы рендера на экране", Category.RENDER, true));

        // ---- Visual ---- (placeholders — swap these for your real TargetESP/JumpCircle classes)
        Module targetEsp = new Module("targetesp", "TargetESP", "Подсветка выбранной цели", Category.VISUAL, true);
        targetEsp.addSetting(new Setting("Толщина", 0.5f, 4f, 1.5f));
        targetEsp.addSetting(new Setting("Прозрачность", 0f, 1f, 0.6f));
        register(targetEsp);

        Module jumpCircle = new Module("jumpcircle", "JumpCircle", "Круг под ногами при прыжке", Category.VISUAL, true);
        jumpCircle.addSetting(new Setting("Радиус", 0.2f, 3f, 1.0f));
        jumpCircle.addSetting(new Setting("Скорость", 0.1f, 3f, 1.0f));
        register(jumpCircle);

        register(new Module("trails", "Trails", "Шлейф движения игрока", Category.VISUAL, false));
        register(new Module("chams", "Chams", "Подсветка сущностей сквозь стены", Category.VISUAL, false));

        // ---- Utilities ----
        register(new Module("automodule", "AutoModule", "Заглушка утилитарного модуля", Category.UTILITIES, false));
        register(new Module("fastplace", "FastPlace", "Заглушка утилитарного модуля", Category.UTILITIES, false));

        // ---- Misc ----
        register(new Module("watermark", "Watermark", "Водяной знак wexyvisuals в углу экрана", Category.MISC, true));
        register(new Module("notifications", "Notifications", "Всплывающие уведомления клиента", Category.MISC, true));
    }

    public static void register(Module module) {
        MODULES.add(module);
    }

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> byCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == category) out.add(m);
        return out;
    }

    public static Map<Category, List<Module>> grouped() {
        Map<Category, List<Module>> map = new EnumMap<>(Category.class);
        for (Category c : Category.values()) map.put(c, byCategory(c));
        return map;
    }
}
