package com.wexy.visuals.module;

/**
 * A single adjustable value inside a module's settings panel (right column in the GUI).
 * Placeholder implementation — value has no gameplay effect yet. Wire it up from your
 * own module logic by reading getValue() wherever the feature needs it.
 */
public class Setting {

    public final String label;
    public final float min;
    public final float max;
    private float value;

    public Setting(String label, float min, float max, float defaultValue) {
        this.label = label;
        this.min = min;
        this.max = max;
        this.value = defaultValue;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public float getFraction() {
        return (value - min) / (max - min);
    }

    public void setFraction(float frac) {
        setValue(min + frac * (max - min));
    }
}
