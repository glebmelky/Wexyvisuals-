package com.wexy.visuals.font;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferRenderer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBTTFontinfo;
import org.lwjgl.stb.STBTTPackContext;
import org.lwjgl.stb.STBTTPackedchar;
import org.lwjgl.stb.STBTruetype;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * Loads a bundled TTF (see assets/wexyvisuals/fonts) and renders it via an STB-packed texture
 * atlas, completely independent from Minecraft's vanilla bitmap font. This is what gives the
 * ClickGUI the "SF Pro / Poppins-style" rounded, modern look instead of the default blocky
 * Minecraft font.
 *
 * Usage: CustomFont.BOLD.drawText(ctx, "wexyvisuals", x, y, size, color);
 */
public class CustomFont {

    public static final CustomFont REGULAR = new CustomFont("wexy_regular.ttf", "wexyvisuals_font_regular");
    public static final CustomFont BOLD = new CustomFont("wexy_bold.ttf", "wexyvisuals_font_bold");

    private static final int ATLAS_SIZE = 512;
    private static final int FIRST_CHAR = 32;
    private static final int NUM_CHARS = 224; // covers ASCII + basic Latin-1, enough for RU transliteration UI labels

    private final String resourcePath;
    private final String textureKey;
    private Identifier textureId;
    private STBTTPackedchar.Buffer charData;
    private float atlasFontPx = 48f; // baked size; scaled at draw time
    private boolean loaded = false;

    private CustomFont(String fileName, String textureKey) {
        this.resourcePath = "/assets/wexyvisuals/fonts/" + fileName;
        this.textureKey = textureKey;
    }

    private void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        try {
            ByteBuffer ttf = readResourceToBuffer(resourcePath);
            if (ttf == null) {
                return; // Falls back to vanilla font automatically if bake fails; see FontRenderer2D.
            }

            ByteBuffer bitmap = BufferUtils.createByteBuffer(ATLAS_SIZE * ATLAS_SIZE);
            charData = STBTTPackedchar.malloc(NUM_CHARS);

            try (MemoryStack stack = MemoryStack.stackPush()) {
                STBTTPackContext pc = STBTTPackContext.malloc(stack);
                STBTruetype.stbtt_PackBegin(pc, bitmap, ATLAS_SIZE, ATLAS_SIZE, 0, 1, MemoryUtil.NULL);
                STBTruetype.stbtt_PackSetOversampling(pc, 2, 2);
                STBTruetype.stbtt_PackFontRange(pc, ttf, 0, atlasFontPx, FIRST_CHAR, charData);
                STBTruetype.stbtt_PackEnd(pc);
            }

            NativeImage image = new NativeImage(NativeImage.Format.LUMINANCE, ATLAS_SIZE, ATLAS_SIZE, false);
            for (int yy = 0; yy < ATLAS_SIZE; yy++) {
                for (int xx = 0; xx < ATLAS_SIZE; xx++) {
                    int alpha = bitmap.get(yy * ATLAS_SIZE + xx) & 0xFF;
                    int argb = (alpha << 24) | 0xFFFFFF;
                    image.setColor(xx, yy, argb);
                }
            }

            NativeImageBackedTexture tex = new NativeImageBackedTexture(() -> textureKey, image);
            textureId = MinecraftClient.getInstance().getTextureManager()
                    .registerDynamicTexture("wexyvisuals_" + textureKey, tex);

            MemoryUtil.memFree(ttf);
        } catch (Exception e) {
            // Bake failed (missing font resource, unsupported platform, etc). GUI code checks
            // isReady() and falls back to vanilla MinecraftClient.textRenderer in that case.
            loaded = true;
            charData = null;
        }
    }

    public boolean isReady() {
        ensureLoaded();
        return charData != null && textureId != null;
    }

    /** Width of the given text at the requested pixel size. */
    public float width(String text, float sizePx) {
        ensureLoaded();
        if (!isReady()) {
            return MinecraftClient.getInstance().textRenderer.getWidth(text) * (sizePx / 9f);
        }
        float scale = sizePx / atlasFontPx;
        float w = 0f;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var xBuf = stack.floats(0f);
            var yBuf = stack.floats(0f);
            var q = org.lwjgl.stb.STBTTAlignedQuad.malloc(stack);
            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                if (c < FIRST_CHAR || c >= FIRST_CHAR + NUM_CHARS) continue;
                STBTruetype.stbtt_GetPackedQuad(charData, ATLAS_SIZE, ATLAS_SIZE, c - FIRST_CHAR, xBuf, yBuf, q, false);
            }
            w = xBuf.get(0) * scale;
        }
        return w;
    }

    /** Draws text with the baseline roughly aligned like vanilla text rendering (top-left origin). */
    public void drawText(DrawContext ctx, String text, float x, float y, float sizePx, int argb) {
        ensureLoaded();
        if (!isReady()) {
            // Graceful fallback so the GUI never crashes if the font resource is missing.
            ctx.drawText(MinecraftClient.getInstance().textRenderer, text, (int) x, (int) y, argb, false);
            return;
        }

        float scale = sizePx / atlasFontPx;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        float a = ((argb >>> 24) & 0xFF) / 255f;
        if (a <= 0f) a = 1f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderTexture(0, textureId);
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);

        var matrix = ctx.getMatrices().peek().getPositionMatrix();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormat.PositionTexColor.POSITION_TEX_COLOR);

        try (MemoryStack stack = MemoryStack.stackPush()) {
            var xBuf = stack.floats(0f);
            var yBuf = stack.floats(0f);
            var q = org.lwjgl.stb.STBTTAlignedQuad.malloc(stack);

            float penY = y + atlasFontPx * scale * 0.75f; // approximate baseline offset

            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                if (c < FIRST_CHAR || c >= FIRST_CHAR + NUM_CHARS) continue;

                float beforeX = xBuf.get(0);
                STBTruetype.stbtt_GetPackedQuad(charData, ATLAS_SIZE, ATLAS_SIZE, c - FIRST_CHAR, xBuf, yBuf, q, false);

                float qx0 = x + beforeX * scale + (q.x0() - beforeX) * scale;
                float qx1 = x + beforeX * scale + (q.x1() - beforeX) * scale;
                float qy0 = penY + q.y0() * scale;
                float qy1 = penY + q.y1() * scale;

                buf.vertex(matrix, qx0, qy0, 0).texture(q.s0(), q.t0()).color(r, g, b, a);
                buf.vertex(matrix, qx0, qy1, 0).texture(q.s0(), q.t1()).color(r, g, b, a);
                buf.vertex(matrix, qx1, qy1, 0).texture(q.s1(), q.t1()).color(r, g, b, a);
                buf.vertex(matrix, qx1, qy0, 0).texture(q.s1(), q.t0()).color(r, g, b, a);
            }
        }

        BufferRenderer.drawWithGlobalProgram(buf.end());
        RenderSystem.disableBlend();
    }

    private static ByteBuffer readResourceToBuffer(String path) throws IOException {
        try (InputStream in = CustomFont.class.getResourceAsStream(path)) {
            if (in == null) return null;
            byte[] bytes = in.readAllBytes();
            ByteBuffer buffer = MemoryUtil.memAlloc(bytes.length);
            buffer.put(bytes);
            buffer.flip();
            return buffer;
        }
    }
}
