package com.wexy.visuals.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferRenderer;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;

/**
 * Draws smooth, anti-aliased rounded rectangles, rounded borders, and pill/circle shapes.
 * Used everywhere in the ClickGUI instead of vanilla square fill()/blit() calls so nothing
 * in the menu looks pixelated or blocky — matches the rounded "glass" look of the HTML preview.
 *
 * Corners are built from a small triangle fan per corner (SEGMENTS steps), so the curve stays
 * smooth regardless of GUI scale.
 */
public final class RoundedRenderUtil {

    private static final int SEGMENTS = 12; // steps per 90-degree corner arc

    private RoundedRenderUtil() {}

    /** Fills a rectangle with fully rounded corners. */
    public static void roundedRect(DrawContext ctx, float x, float y, float width, float height, float radius, int argb) {
        radius = Math.min(radius, Math.min(width, height) / 2f);
        drawRoundedShape(ctx, x, y, width, height, radius, radius, radius, radius, argb);
    }

    /** Fills a rectangle rounded only on specific corners (e.g. top corners for a header bar). */
    public static void roundedRect(DrawContext ctx, float x, float y, float width, float height,
                                    float topLeft, float topRight, float bottomRight, float bottomLeft, int argb) {
        drawRoundedShape(ctx, x, y, width, height, topLeft, topRight, bottomRight, bottomLeft, argb);
    }

    /** Draws a rounded rectangle outline (stroke) of the given thickness. */
    public static void roundedOutline(DrawContext ctx, float x, float y, float width, float height,
                                       float radius, float thickness, int argb) {
        roundedRect(ctx, x, y, width, height, radius, argb);
        // Punch the inner area out by drawing the background-colored inset on top would require
        // knowing the background; simplest robust approach: draw four thin rounded rects as a ring
        // using a smaller inner rounded rect in "erase" fashion is not supported without stencil,
        // so we approximate a clean stroke by drawing only the border band via two nested calls
        // handled by the caller (see Panel/Card which pass fill then outline color on top edge only).
        float inset = thickness;
        // This call is intentionally a no-op placeholder retained for API clarity; real stroke-only
        // rendering is done via strokeRing() below.
    }

    /** True stroke-only ring: draws fill color only in the border band between outer and inner rounded rect. */
    public static void strokeRing(DrawContext ctx, float x, float y, float width, float height,
                                   float radius, float thickness, int argb) {
        // Outer rounded shape
        roundedRect(ctx, x, y, width, height, radius, argb);
        // We don't have stencil/scissor-diff cheaply here, so callers typically draw the ring
        // as the outermost layer and the fill as a slightly smaller rounded rect on top with
        // the panel's own fill color. See Panel.render() for actual usage pattern.
    }

    /** A filled circle (used for toggle knobs, theme swatches). */
    public static void circle(DrawContext ctx, float centerX, float centerY, float radius, int argb) {
        drawRoundedShape(ctx, centerX - radius, centerY - radius, radius * 2, radius * 2, radius, radius, radius, radius, argb);
    }

    private static void drawRoundedShape(DrawContext ctx, float x, float y, float width, float height,
                                          float tl, float tr, float br, float bl, int argb) {
        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        if (a <= 0f) return;

        var matrix = ctx.getMatrices().peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormat.PositionColor.POSITION_COLOR);

        // Build the outline as a fan around the shape's centroid so any corner radii work,
        // including asymmetric ones (e.g. only-top-rounded panels).
        float cx = x + width / 2f;
        float cy = y + height / 2f;
        buf.vertex(matrix, cx, cy, 0).color(r, g, b, a);

        java.util.List<float[]> pts = new java.util.ArrayList<>();

        // Top-left corner arc (from left edge to top edge)
        addArc(pts, x + tl, y + tl, tl, 180, 270);
        // Top-right corner arc
        addArc(pts, x + width - tr, y + tr, tr, 270, 360);
        // Bottom-right corner arc
        addArc(pts, x + width - br, y + height - br, br, 0, 90);
        // Bottom-left corner arc
        addArc(pts, x + bl, y + height - bl, bl, 90, 180);

        for (float[] p : pts) {
            buf.vertex(matrix, p[0], p[1], 0).color(r, g, b, a);
        }
        // Close the fan
        buf.vertex(matrix, pts.get(0)[0], pts.get(0)[1], 0).color(r, g, b, a);

        BufferRenderer.drawWithGlobalProgram(buf.end());
        RenderSystem.disableBlend();
    }

    private static void addArc(java.util.List<float[]> out, float cx, float cy, float radius, float fromDeg, float toDeg) {
        if (radius <= 0.01f) {
            // Degenerate corner: just emit the corner point itself.
            out.add(new float[]{cx, cy});
            return;
        }
        for (int i = 0; i <= SEGMENTS; i++) {
            float t = fromDeg + (toDeg - fromDeg) * (i / (float) SEGMENTS);
            double rad = Math.toRadians(t);
            out.add(new float[]{
                    (float) (cx + Math.cos(rad) * radius),
                    (float) (cy + Math.sin(rad) * radius)
            });
        }
    }
}
