package com.wexy.visuals.gui.widget;

import com.wexy.visuals.font.CustomFont;
import com.wexy.visuals.gui.RoundedRenderUtil;
import com.wexy.visuals.module.Setting;
import com.wexy.visuals.theme.ThemeManager;
import net.minecraft.client.gui.DrawContext;

/**
 * A slider with a filled track, a round draggable knob, a label on the left and the live
 * numeric value on the right — matches the "RightX / -0.2" style rows in the mockup.
 */
public class SliderWidget {

    private static final int TRACK_HEIGHT = 6;
    private static final int KNOB_RADIUS = 9;

    private boolean dragging = false;

    public int render(DrawContext ctx, Setting setting, int x, int y, int width) {
        int labelY = y;
        CustomFont.BOLD.drawText(ctx, setting.label, x, labelY, 13f, ThemeManager.get().textMain);

        String valueText = formatValue(setting.getValue());
        float valueWidth = CustomFont.REGULAR.width(valueText, 13f);
        CustomFont.REGULAR.drawText(ctx, valueText, x + width - valueWidth, labelY, 13f, ThemeManager.get().textSub);

        int trackY = y + 20;
        RoundedRenderUtil.roundedRect(ctx, x, trackY, width, TRACK_HEIGHT, TRACK_HEIGHT / 2f, ThemeManager.get().trackColor);

        float fillWidth = width * setting.getFraction();
        if (fillWidth > 1f) {
            RoundedRenderUtil.roundedRect(ctx, x, trackY, fillWidth, TRACK_HEIGHT, TRACK_HEIGHT / 2f, ThemeManager.get().accent());
        }

        float knobX = x + fillWidth;
        float knobY = trackY + TRACK_HEIGHT / 2f;
        RoundedRenderUtil.circle(ctx, knobX, knobY, KNOB_RADIUS, 0xFFFFFFFF);
        RoundedRenderUtil.circle(ctx, knobX, knobY, KNOB_RADIUS - 6, ThemeManager.get().accent());

        return trackY + TRACK_HEIGHT + 18; // next Y offset for stacking sliders
    }

    public boolean mouseClicked(Setting setting, double mouseX, double mouseY, int x, int trackY, int width) {
        if (mouseY >= trackY - 8 && mouseY <= trackY + TRACK_HEIGHT + 8 && mouseX >= x - 10 && mouseX <= x + width + 10) {
            dragging = true;
            updateFromMouse(setting, mouseX, x, width);
            return true;
        }
        return false;
    }

    public void mouseDragged(Setting setting, double mouseX, int x, int width) {
        if (dragging) updateFromMouse(setting, mouseX, x, width);
    }

    public void mouseReleased() {
        dragging = false;
    }

    private void updateFromMouse(Setting setting, double mouseX, int x, int width) {
        float frac = (float) ((mouseX - x) / width);
        frac = Math.max(0f, Math.min(1f, frac));
        setting.setFraction(frac);
    }

    private static String formatValue(float v) {
        if (Math.abs(v - Math.round(v)) < 0.001f) return String.valueOf(Math.round(v));
        return String.format("%.1f", v);
    }
}
