package com.wexy.visuals.gui;

import com.wexy.visuals.font.CustomFont;
import com.wexy.visuals.gui.widget.SliderWidget;
import com.wexy.visuals.gui.widget.ToggleSwitch;
import com.wexy.visuals.module.Category;
import com.wexy.visuals.module.Module;
import com.wexy.visuals.module.ModuleRegistry;
import com.wexy.visuals.module.Setting;
import com.wexy.visuals.theme.Theme;
import com.wexy.visuals.theme.ThemeManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The wexyvisuals ClickGUI. Layout mirrors the approved HTML preview 1:1:
 *   [ sidebar 250px | module grid (flex) | settings panel 300px ]
 *   [                theme swatch bar (full width)               ]
 *
 * Everything is drawn with RoundedRenderUtil (no square vanilla fill()) and CustomFont
 * (no default Minecraft bitmap font), so the panel matches the approved mockup exactly.
 */
public class ClickGuiScreen extends Screen {

    private static final int SIDEBAR_W = 250;
    private static final int SETTINGS_W = 300;
    private static final int THEME_BAR_H = 58;
    private static final int PANEL_MARGIN = 40; // breathing room from window edges, like the mockup's centered card

    private Category currentCategory = Category.RENDER;
    private Module selectedModule = null;
    private String searchQuery = "";

    private final Map<String, ToggleSwitch> toggles = new HashMap<>();
    private final Map<Setting, SliderWidget> sliders = new HashMap<>();

    private int panelX, panelY, panelW, panelH;

    public ClickGuiScreen() {
        super(Text.literal("wexyvisuals"));
        ModuleRegistry.init();
    }

    @Override
    protected void init() {
        panelW = Math.min(1300, this.width - PANEL_MARGIN * 2);
        panelH = Math.min(820, this.height - PANEL_MARGIN * 2);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackdrop(ctx);

        // Outer glass panel
        RoundedRenderUtil.roundedRect(ctx, panelX, panelY, panelW, panelH, 32f, ThemeManager.get().panelFill);
        RoundedRenderUtil.strokeRing(ctx, panelX, panelY, panelW, panelH, 32f, 1.5f, ThemeManager.get().panelBorder);

        int contentH = panelH - THEME_BAR_H;

        renderSidebar(ctx, mouseX, mouseY, panelX, panelY, SIDEBAR_W, contentH);

        int gridX = panelX + SIDEBAR_W;
        int gridW = panelW - SIDEBAR_W - SETTINGS_W;
        renderGrid(ctx, mouseX, mouseY, gridX, panelY, gridW, contentH, delta);

        int settingsX = panelX + panelW - SETTINGS_W;
        renderSettingsPanel(ctx, settingsX, panelY, SETTINGS_W, contentH);

        renderThemeBar(ctx, mouseX, mouseY, panelX, panelY + contentH, panelW, THEME_BAR_H);

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void renderBackdrop(DrawContext ctx) {
        // Soft vertical gradient behind the panel, echoing the water-themed backdrop in the mockup.
        ctx.fillGradient(0, 0, this.width, this.height, ThemeManager.get().bgTop, ThemeManager.get().bgBottom);
    }

    // ---------------------------------------------------------------- Sidebar

    private void renderSidebar(DrawContext ctx, int mouseX, int mouseY, int x, int y, int w, int h) {
        CustomFont.BOLD.drawText(ctx, "wexyvisuals", x + 28, y + 30, 19f, ThemeManager.get().textMain);
        RoundedRenderUtil.circle(ctx, x + 18, y + 36, 5.5f, ThemeManager.get().accent());

        // Search box
        int searchY = y + 68;
        RoundedRenderUtil.roundedRect(ctx, x + 20, searchY, w - 40, 40, 14f, 0x8CFFFFFF);
        String placeholder = searchQuery.isEmpty() ? "Поиск..." : searchQuery;
        int placeholderColor = searchQuery.isEmpty() ? ThemeManager.get().textSub : ThemeManager.get().textMain;
        CustomFont.REGULAR.drawText(ctx, placeholder, x + 36, searchY + 13, 13f, placeholderColor);

        int catY = searchY + 60;
        for (Category cat : Category.values()) {
            boolean active = cat == currentCategory;
            boolean hovered = mouseX >= x + 20 && mouseX <= x + w - 20 && mouseY >= catY && mouseY <= catY + 44;

            if (active) {
                RoundedRenderUtil.roundedRect(ctx, x + 20, catY, w - 40, 44, 14f, 0xBFFFFFFF);
            } else if (hovered) {
                RoundedRenderUtil.roundedRect(ctx, x + 20, catY, w - 40, 44, 14f, 0x66FFFFFF);
            }

            int textColor = active ? ThemeManager.get().accentDark() : ThemeManager.get().textMain;
            CustomFont.BOLD.drawText(ctx, cat.displayName, x + 44, catY + 14, 15f, textColor);
            RoundedRenderUtil.circle(ctx, x + 32, catY + 22, 4f, textColor);

            catY += 50;
        }
    }

    // ---------------------------------------------------------------- Module grid

    private void renderGrid(DrawContext ctx, int mouseX, int mouseY, int x, int y, int w, int h, float delta) {
        int padding = 26;
        CustomFont.BOLD.drawText(ctx, "Категория: " + currentCategory.displayName, x + padding, y + 28, 16f, ThemeManager.get().textMain);
        CustomFont.REGULAR.drawText(ctx, "Модули этой категории", x + padding, y + 48, 12.5f, ThemeManager.get().textSub);

        int gridTop = y + 78;
        int cols = 2;
        int gap = 16;
        int cardW = (w - padding * 2 - gap) / cols;
        int cardH = 74;

        List<Module> modules = ModuleRegistry.byCategory(currentCategory);
        int col = 0, row = 0;
        for (Module mod : modules) {
            if (!searchQuery.isEmpty() && !mod.name.toLowerCase().contains(searchQuery.toLowerCase())) continue;

            int cx = x + padding + col * (cardW + gap);
            int cy = gridTop + row * (cardH + gap);

            boolean hovered = mouseX >= cx && mouseX <= cx + cardW && mouseY >= cy && mouseY <= cy + cardH;
            boolean selected = mod == selectedModule;

            int fill = hovered ? ThemeManager.get().cardFillHover : ThemeManager.get().cardFill;
            RoundedRenderUtil.roundedRect(ctx, cx, cy, cardW, cardH, 18f, fill);
            if (selected) {
                RoundedRenderUtil.strokeRing(ctx, cx, cy, cardW, cardH, 18f, 2f, (ThemeManager.get().accent() & 0x00FFFFFF) | 0x8C000000);
            }

            CustomFont.BOLD.drawText(ctx, mod.name, cx + 18, cy + 14, 14.5f, ThemeManager.get().textMain);
            CustomFont.REGULAR.drawText(ctx, mod.description, cx + 18, cy + 34, 11.5f, ThemeManager.get().textSub);

            ToggleSwitch toggle = toggles.computeIfAbsent(mod.id, k -> new ToggleSwitch());
            int toggleX = cx + cardW - ToggleSwitch.width() - 16;
            int toggleY = cy + (cardH - ToggleSwitch.height()) / 2;
            toggle.render(ctx, toggleX, toggleY, mod.isEnabled(), delta);

            col++;
            if (col >= cols) { col = 0; row++; }
        }
    }

    // ---------------------------------------------------------------- Settings panel

    private void renderSettingsPanel(DrawContext ctx, int x, int y, int w, int h) {
        int padding = 24;
        if (selectedModule == null) {
            CustomFont.BOLD.drawText(ctx, "Настройки", x + padding, y + 28, 16f, ThemeManager.get().textMain);
            CustomFont.REGULAR.drawText(ctx, "Выберите модуль слева", x + padding, y + 52, 13f, ThemeManager.get().textSub);
            return;
        }

        CustomFont.BOLD.drawText(ctx, "Настройки: " + selectedModule.name, x + padding, y + 28, 16f, ThemeManager.get().textMain);
        CustomFont.REGULAR.drawText(ctx, selectedModule.description, x + padding, y + 50, 12.5f, ThemeManager.get().textSub);

        List<Setting> settings = selectedModule.getSettings();
        if (settings.isEmpty()) {
            CustomFont.REGULAR.drawText(ctx, "У этого модуля пока нет", x + padding, y + 86, 13f, ThemeManager.get().textSub);
            CustomFont.REGULAR.drawText(ctx, "дополнительных настроек.", x + padding, y + 104, 13f, ThemeManager.get().textSub);
            return;
        }

        int sliderY = y + 90;
        int sliderW = w - padding * 2;
        for (Setting s : settings) {
            SliderWidget widget = sliders.computeIfAbsent(s, k -> new SliderWidget());
            sliderY = widget.render(ctx, s, x + padding, sliderY, sliderW);
        }
    }

    // ---------------------------------------------------------------- Theme bar

    private void renderThemeBar(DrawContext ctx, int mouseX, int mouseY, int x, int y, int w, int h) {
        Theme[] themes = Theme.ALL;
        int swatchR = 13;
        int gap = 24;
        int totalW = themes.length * (swatchR * 2) + (themes.length - 1) * gap + gap + swatchR * 2; // + add button
        int startX = x + (w - totalW) / 2 + swatchR;
        int cy = y + h / 2;

        for (Theme t : themes) {
            boolean active = t == ThemeManager.get().getCurrent();
            boolean hovered = dist(mouseX, mouseY, startX, cy) <= swatchR + 3;

            if (active || hovered) {
                RoundedRenderUtil.circle(ctx, startX, cy, swatchR + 4, 0x40000000);
            }
            RoundedRenderUtil.circle(ctx, startX, cy, swatchR, t.accent);
            startX += swatchR * 2 + gap;
        }

        // "+" add-theme button (visual only placeholder, matches mockup)
        RoundedRenderUtil.circle(ctx, startX, cy, swatchR, 0x66FFFFFF);
        CustomFont.BOLD.drawText(ctx, "+", startX - 4, cy - 7, 14f, ThemeManager.get().textSub);
    }

    private static double dist(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    }

    // ---------------------------------------------------------------- Input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int contentH = panelH - THEME_BAR_H;

        // Sidebar category clicks
        if (mouseX >= panelX && mouseX <= panelX + SIDEBAR_W) {
            int catY = panelY + 68 + 60;
            for (Category cat : Category.values()) {
                if (mouseX >= panelX + 20 && mouseX <= panelX + SIDEBAR_W - 20 && mouseY >= catY && mouseY <= catY + 44) {
                    currentCategory = cat;
                    selectedModule = null;
                    return true;
                }
                catY += 50;
            }
        }

        // Grid: module card / toggle clicks
        int gridX = panelX + SIDEBAR_W;
        int gridW = panelW - SIDEBAR_W - SETTINGS_W;
        if (handleGridClick(mouseX, mouseY, gridX, panelY, gridW, contentH)) return true;

        // Settings panel: slider drag start
        int settingsX = panelX + panelW - SETTINGS_W;
        if (handleSliderClick(mouseX, mouseY, settingsX, panelY)) return true;

        // Theme bar clicks
        if (handleThemeClick(mouseX, mouseY, panelX, panelY + contentH, panelW, THEME_BAR_H)) return true;

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean handleGridClick(double mouseX, double mouseY, int x, int y, int w, int h) {
        int padding = 26;
        int gridTop = y + 78;
        int cols = 2;
        int gap = 16;
        int cardW = (w - padding * 2 - gap) / cols;
        int cardH = 74;

        List<Module> modules = ModuleRegistry.byCategory(currentCategory);
        int col = 0, row = 0;
        for (Module mod : modules) {
            if (!searchQuery.isEmpty() && !mod.name.toLowerCase().contains(searchQuery.toLowerCase())) continue;

            int cx = x + padding + col * (cardW + gap);
            int cy = gridTop + row * (cardH + gap);

            ToggleSwitch toggle = toggles.get(mod.id);
            int toggleX = cx + cardW - ToggleSwitch.width() - 16;
            int toggleY = cy + (cardH - ToggleSwitch.height()) / 2;

            if (toggle != null && toggle.isHovered((int) mouseX, (int) mouseY, toggleX, toggleY)) {
                mod.toggle();
                return true;
            }

            if (mouseX >= cx && mouseX <= cx + cardW && mouseY >= cy && mouseY <= cy + cardH) {
                selectedModule = mod;
                return true;
            }

            col++;
            if (col >= cols) { col = 0; row++; }
        }
        return false;
    }

    private boolean handleSliderClick(double mouseX, double mouseY, int x, int y) {
        if (selectedModule == null) return false;
        int padding = 24;
        int sliderY = y + 90;
        int sliderW = SETTINGS_W - padding * 2;

        for (Setting s : selectedModule.getSettings()) {
            SliderWidget widget = sliders.computeIfAbsent(s, k -> new SliderWidget());
            int trackY = sliderY + 20;
            if (widget.mouseClicked(s, mouseX, mouseY, x + padding, trackY, sliderW)) return true;
            sliderY = trackY + 6 + 18;
        }
        return false;
    }

    private boolean handleThemeClick(double mouseX, double mouseY, int x, int y, int w, int h) {
        Theme[] themes = Theme.ALL;
        int swatchR = 13;
        int gap = 24;
        int totalW = themes.length * (swatchR * 2) + (themes.length - 1) * gap + gap + swatchR * 2;
        int startX = x + (w - totalW) / 2 + swatchR;
        int cy = y + h / 2;

        for (Theme t : themes) {
            if (dist(mouseX, mouseY, startX, cy) <= swatchR + 3) {
                ThemeManager.get().setCurrent(t);
                return true;
            }
            startX += swatchR * 2 + gap;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (selectedModule != null) {
            int padding = 24;
            int settingsX = panelX + panelW - SETTINGS_W;
            int sliderY = panelY + 90;
            int sliderW = SETTINGS_W - padding * 2;
            for (Setting s : selectedModule.getSettings()) {
                SliderWidget widget = sliders.computeIfAbsent(s, k -> new SliderWidget());
                int trackY = sliderY + 20;
                widget.mouseDragged(s, mouseX, settingsX + padding, sliderW);
                sliderY = trackY + 6 + 18;
            }
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (SliderWidget w : sliders.values()) w.mouseReleased();
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        searchQuery += chr;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Right Shift closes the GUI again (the global keybind tick hook only fires when no
        // screen is open, so closing has to be handled here instead).
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.close();
            return true;
        }
        if (keyCode == 259 && !searchQuery.isEmpty()) { // GLFW_KEY_BACKSPACE
            searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
