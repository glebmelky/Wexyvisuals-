package com.wexy.visuals.module;

/**
 * Sidebar sections, matching the mockup icons: Render / Visual / Utilities / Misc.
 */
public enum Category {
    RENDER("Render"),
    VISUAL("Visual"),
    UTILITIES("Utilities"),
    MISC("Misc");

    public final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }
}
