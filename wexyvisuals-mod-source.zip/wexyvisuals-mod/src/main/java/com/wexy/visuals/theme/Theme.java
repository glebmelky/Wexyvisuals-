package com.wexy.visuals.theme;

/**
 * A single accent color theme. Mirrors the color swatches in the HTML preview
 * (white / blue / orange / green / cyan / pink / teal).
 */
public class Theme {

    public final String name;
    public final int accent;      // ARGB
    public final int accentDark;  // ARGB, used for hover/active states

    public Theme(String name, int accent, int accentDark) {
        this.name = name;
        this.accent = accent;
        this.accentDark = accentDark;
    }

    public static final Theme WHITE  = new Theme("white",  0xFF93A3AD, 0xFF7C8E99);
    public static final Theme BLUE   = new Theme("blue",   0xFF2F8DFA, 0xFF1F6FD4);
    public static final Theme ORANGE = new Theme("orange", 0xFFF6A13A, 0xFFDC8A22);
    public static final Theme GREEN  = new Theme("green",  0xFF3FBF6A, 0xFF2EA355);
    public static final Theme CYAN   = new Theme("cyan",   0xFF2BC7D6, 0xFF1AA9B8);
    public static final Theme PINK   = new Theme("pink",   0xFFE8477A, 0xFFCF2F63);
    public static final Theme TEAL   = new Theme("teal",   0xFF5FC9B0, 0xFF43AB93);

    public static final Theme[] ALL = { WHITE, BLUE, ORANGE, GREEN, CYAN, PINK, TEAL };
}
