package com.wexy.visuals;

import com.wexy.visuals.gui.ClickGuiScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Registers the "Open wexyvisuals ClickGUI" keybind, defaulting to Right Shift as requested.
 * Configurable later by the user in Options > Controls like any other keybind.
 */
public final class KeyBindings {

    public static KeyBinding openClickGui;

    private KeyBindings() {}

    public static void register() {
        openClickGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wexyvisuals.open_clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.wexyvisuals.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openClickGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
        });
    }
}
