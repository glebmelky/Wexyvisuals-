package com.wexy.visuals;

import net.fabricmc.api.ClientModInitializer;

/**
 * Entrypoint declared in fabric.mod.json ("client" -> com.wexy.visuals.WexyVisualsClient).
 * Registers the keybind and prepares the module registry.
 */
public class WexyVisualsClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        KeyBindings.register();
        com.wexy.visuals.module.ModuleRegistry.init();
    }
}
