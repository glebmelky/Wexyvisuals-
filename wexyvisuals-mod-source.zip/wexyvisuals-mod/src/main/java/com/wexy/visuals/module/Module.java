package com.wexy.visuals.module;

import java.util.ArrayList;
import java.util.List;

/**
 * A single module card, e.g. "TargetESP" or "JumpCircle". This is a GUI-side placeholder:
 * it just tracks on/off + its settings. Plug your own feature logic in by checking
 * module.isEnabled() from a HandledScreen/render event/tick hook in your own class, or by
 * subclassing Module and overriding onEnable()/onDisable() below.
 */
public class Module {

    public final String id;
    public final String name;
    public final String description;
    public final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    public Module(String id, String name, String description, Category category, boolean defaultEnabled) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = defaultEnabled;
    }

    public Module addSetting(Setting setting) {
        settings.add(setting);
        return this;
    }

    public List<Setting> getSettings() {
        return settings;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        boolean was = this.enabled;
        this.enabled = enabled;
        if (!was && enabled) onEnable();
        if (was && !enabled) onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    /** Override in a subclass to hook actual feature start-up logic (e.g. register a render callback). */
    protected void onEnable() {}

    /** Override in a subclass to hook actual feature shutdown logic. */
    protected void onDisable() {}
}
