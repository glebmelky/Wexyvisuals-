package com.wexy.visuals.theme;

/**
 * Holds the currently active theme for the whole ClickGUI.
 * Panels/cards read from here so switching a swatch re-themes everything at once,
 * same as clicking a color dot in the HTML preview's bottom bar.
 */
public class ThemeManager {

    private static ThemeManager instance;

    private Theme current = Theme.BLUE;

    // Base "wave" light palette — matches the light blue/white glass look in the mockup.
    public int bgTop = 0xFFDFF1FB;
    public int bgBottom = 0xFFEEF8FD;
    public int panelFill = 0x8CFFFFFF;      // translucent white panel
    public int panelBorder = 0x99FFFFFF;
    public int cardFill = 0x99FFFFFF;
    public int cardFillHover = 0xD9FFFFFF;
    public int textMain = 0xFF0E2233;
    public int textSub = 0xFF5C7686;
    public int trackColor = 0xFFC9DBE6;

    public static ThemeManager get() {
        if (instance == null) instance = new ThemeManager();
        return instance;
    }

    public Theme getCurrent() {
        return current;
    }

    public void setCurrent(Theme theme) {
        this.current = theme;
    }

    public int accent() {
        return current.accent;
    }

    public int accentDark() {
        return current.accentDark;
    }
}
