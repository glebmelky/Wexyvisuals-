package com.wexy.visuals.gui.widget;

import com.wexy.visuals.gui.RoundedRenderUtil;
import com.wexy.visuals.theme.ThemeManager;
import net.minecraft.client.gui.DrawContext;

/**
 * Pill-shaped on/off switch, matching the toggle in each module card of the mockup.
 * Animates the knob position smoothly instead of snapping instantly.
 */
public class ToggleSwitch {

    private static final int WIDTH = 34;
    private static final int HEIGHT = 20;

    private float animProgress; // 0 = off, 1 = on

    public void render(DrawContext ctx, int x, int y, boolean on, float delta) {
        float target = on ? 1f : 0f;
        animProgress += (target - animProgress) * Math.min(1f, delta * 0.4f);
        if (Math.abs(target - animProgress) < 0.01f) animProgress = target;

        int trackColor = lerpColor(ThemeManager.get().trackColor, ThemeManager.get().accent(), animProgress);
        RoundedRenderUtil.roundedRect(ctx, x, y, WIDTH, HEIGHT, HEIGHT / 2f, trackColor);

        float knobRadius = (HEIGHT - 6) / 2f;
        float knobX = x + knobRadius + 3 + (WIDTH - HEIGHT) * animProgress;
        float knobY = y + HEIGHT / 2f;
        RoundedRenderUtil.circle(ctx, knobX, knobY, knobRadius, 0xFFFFFFFF);
    }

    public boolean isHovered(int mouseX, int mouseY, int x, int y) {
        return mouseX >= x && mouseX <= x + WIDTH && mouseY >= y && mouseY <= y + HEIGHT;
    }

    public static int width() { return WIDTH; }
    public static int height() { return HEIGHT; }

    private static int lerpColor(int from, int to, float t) {
        int fa = (from >>> 24) & 0xFF, fr = (from >> 16) & 0xFF, fg = (from >> 8) & 0xFF, fb = from & 0xFF;
        int ta = (to >>> 24) & 0xFF, tr = (to >> 16) & 0xFF, tg = (to >> 8) & 0xFF, tb = to & 0xFF;
        int a = (int) (fa + (ta - fa) * t);
        int r = (int) (fr + (tr - fr) * t);
        int g = (int) (fg + (tg - fg) * t);
        int b = (int) (fb + (tb - fb) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
